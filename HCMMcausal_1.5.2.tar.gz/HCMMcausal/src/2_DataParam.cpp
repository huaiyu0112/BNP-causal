#include "2_DataParam.h"

#define LOG_2_PI 1.83787706640935

//////////// CData /////////////////////
// 
CData::CData(){ } 
CData::~CData(){ } //Destructor

void CData::Initialization(){
  
  // n_sample, p_y, p_x is already calculated from Param.Y_mat and Param.X_mat
	// D_l_vec and hyperparameters are already read. 
	nu_sigma = p_y + 1 ; nu_phi = p_y + 2 ;
	Phi_0_mat.eye( p_y, p_y ) ; Phi_0_mat = (1.0/(p_y+1)) * Phi_0_mat ;
	p_x_star = sum(D_l_vec) - p_x + 1 ;
	R = max_R_S_K(0) ; S = max_R_S_K(1) ; K = max_R_S_K(2) ;

	A_ij_cube = arma::zeros<arma::cube>(p_y,p_resp,n_sample) ;
	for (int i_sample=0; i_sample<n_sample; i_sample++){
		for (int i_resp=0; i_resp<p_resp; i_resp++){
			A_ij_cube(i_resp,i_resp,i_sample) = trt_Ind(i_sample) ;
		} // for (i_resp)
	} // for (i_sample)
	
	// std::cout << "                     " << std::endl ;
	// std::cout << "                     " << std::endl ;
	// std::cout << "   ==============    " << std::endl ;
	// std::cout << "       11:55 pm      " << std::endl ;
	// std::cout << "   ==============    " << std::endl ;
	// std::cout << "                     " << std::endl ;
	// std::cout << "                     " << std::endl ;
	
} // void CData::Initialization()

//////////// CParam /////////////////////

CParam::CParam(){ }
CParam::~CParam(){ }

void CParam::Initialization(CData &Data){
  
	p_resp = Data.p_resp ; delta_vec = arma::vec(p_resp) ; delta_vec.fill(0.1) ;

  theta_mat = arma::zeros<arma::mat>(Data.p_y,Data.p_x_star) ;
  tau_inv_diag_vec = arma::vec(Data.p_x_star) ; tau_inv_diag_vec.fill(1.0) ;
  Phi_mat = arma::zeros<arma::mat>(Data.p_y,Data.p_y) ; Phi_mat.diag().fill(1.0) ;
  alpha_R = 1.0 ; alpha_S = 1.0 ; alpha_K = 1.0 ;

  log_eta_mat = arma::mat(Data.K,Data.R) ; log_eta_mat.fill(-1.0 * arma::datum::inf) ;
  for (int k=0; k<Data.K; k++){
    log_eta_mat.row(k).fill(log(1.0/Data.R)) ;
  }
  log_lambda_mat = arma::mat(Data.K,Data.S) ; log_lambda_mat.fill(-1.0 * arma::datum::inf) ;
  for (int k=0; k<Data.K; k++){
    log_lambda_mat.row(k).fill(log(1.0/Data.S)) ;
  }
  log_pi_vec = arma::vec(Data.K) ; log_pi_vec.fill(log(1.0/Data.K)) ;

  psi_cube = arma::zeros<arma::cube>(Data.p_x,Data.S,max(Data.D_l_vec)) ;
  for (int l=0; l<Data.p_x; l++){
    for (int s=0; s<Data.S; s++){
      psi_cube( arma::span(l,l), arma::span(s,s), arma::span(0,Data.D_l_vec(l)-1) ).fill( 1.0/Data.D_l_vec(l) ) ;
    }
  }

  Beta_cube = arma::zeros<arma::cube>(Data.p_y,Data.p_x_star,Data.R) ; // Note: for Beta, slice is changing over r
  UT_Sigma_cube = arma::cube(Data.p_y, Data.p_y, Data.R) ; // Note: for Sigma, slice is changing over r
  arma::mat I_mat = arma::zeros<arma::mat>(Data.p_y,Data.p_y) ; I_mat.diag().fill(1.0) ;
  for (int r=0; r< Data.R; r++) UT_Sigma_cube.slice(r) = I_mat ;

  r_i_vec = arma::zeros<arma::vec>(Data.n_sample) ;
  s_i_vec = arma::zeros<arma::vec>(Data.n_sample) ;
  k_i_vec = arma::zeros<arma::vec>(Data.n_sample) ;

  arma::vec temp_probR(Data.R-5) ; temp_probR.fill(1.0/(Data.R-5)) ; // R, S, K should be greater than 10.
  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
    r_i_vec(i_sample) = rdiscrete_fn(temp_probR) ;
  }
  arma::vec temp_probS(Data.S-5) ; temp_probS.fill(1.0/(Data.S-5)) ; // R, S, K should be greater than 10.
  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
    s_i_vec(i_sample) = rdiscrete_fn(temp_probS) ;
  }
  arma::vec temp_probK(Data.K-5) ; temp_probK.fill(1.0/(Data.K-5)) ; // R, S, K should be greater than 10.
  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
    k_i_vec(i_sample) = rdiscrete_fn(temp_probK) ;
  }

  // NOTE: For DP, distributed membership indicators are always recommended as starting points.
  //       Putting same indicators to all mixture components may have local trap issues.

  n_r_vec = arma::zeros<arma::vec>(Data.R) ; n_s_vec = arma::zeros<arma::vec>(Data.S) ; n_k_vec = arma::zeros<arma::vec>(Data.K) ;
  n_k_r_mat = arma::zeros<arma::mat>(Data.K, Data.R) ;  n_k_s_mat = arma::zeros<arma::mat>(Data.K, Data.S) ;
  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
    int r_i = r_i_vec(i_sample) ; int s_i = s_i_vec(i_sample) ; int k_i = k_i_vec(i_sample) ;
    n_r_vec(r_i) = n_r_vec(r_i) + 1 ; n_s_vec(s_i) = n_s_vec(s_i) + 1 ; n_k_vec(k_i) = n_k_vec(k_i) + 1 ;
    n_k_r_mat(k_i,r_i) = n_k_r_mat(k_i,r_i) + 1 ; n_k_s_mat(k_i,s_i) = n_k_s_mat(k_i,s_i) + 1 ;
  }
  // std::cout << sum(n_r_vec) << std::endl ; std::cout << sum(n_s_vec) << std::endl ; std::cout << sum(n_k_vec) << std::endl ;
 
} // void CParam::Initialization

void CParam::Iterate(int Iter, CData &Data) {
	S1_Beta_cube(Data) ;
  S2_Sigma_cube(Data) ;
  S3_theta_mat(Data) ;
  S4_Phi_mat(Data) ;
  S5_psi_cube(Data) ;

  S6a_log_pi_vec(Data) ;
  S6b_alpha_K(Data) ;
  S6c_k_i_vec(Data) ;

  S7a_log_eta_mat(Data) ;
  S7b_alpha_R(Data) ;
  S7c_r_i_vec(Data) ;

  S8a_log_lambda_mat(Data) ;
  S8b_alpha_S(Data) ;
  S8c_s_i_vec(Data) ;
  S9_tau_inv_diag_vec(Data) ;
  // S10_DA(Data) ;

  S_impute_X_mat(Data) ;
  S_impute_Y_mat(Data) ;
  S_update_delta(Data) ;
  // S_add_test_Y_std_synt(Data) ;
  S_upated_log_prob(Data) ;
}

void CParam::S1_Beta_cube(CData &Data){
  where_we_are = "S1_Beta_cube" ; 
		
  arma::mat T_mat = arma::zeros<arma::mat>(Data.p_x_star,Data.p_x_star) ; T_mat.diag() = tau_inv_diag_vec ;

  for (int r=0; r<Data.R; r++){

    arma::mat Sigma_r = UT_Sigma_cube.slice(r).t() * UT_Sigma_cube.slice(r) ;
    arma::mat B_r = Beta_cube.slice(r) ;  int n_r = n_r_vec(r) ;

    for (int j=0; j<Data.p_y; j++){

      where_we_are = "151" ;

      arma::vec loc_vec = arma::zeros<arma::vec>(Data.p_y) ;  loc_vec(j) = 1 ;
      int n_a = sum(loc_vec) ; int n_b = Data.p_y - n_a ;
      arma::mat Sigma_aa = arma::mat(n_a,n_a) ; arma::mat Sigma_ab = arma::mat(n_a,n_b) ; arma::mat Sigma_bb = arma::mat(n_b,n_b) ;
      arma::mat B_b = arma::mat(n_b,Data.p_x_star) ;
      int count_i_a = 0 ; int count_i_b = 0 ;
      for (int i_var=0; i_var<Data.p_y; i_var++){
        if ( loc_vec(i_var)==1 ){
          int count_j_a = 0 ; int count_j_b = 0 ;
          for (int j_var=0; j_var<Data.p_y; j_var++){
            if ( loc_vec(j_var)==1 ){
              Sigma_aa(count_i_a,count_j_a) = Sigma_r(i_var,j_var) ;
              count_j_a++ ;
            } else {
              Sigma_ab(count_i_a,count_j_b) = Sigma_r(i_var,j_var) ;
              count_j_b++ ;
            } // if (loc_vec(j_var)) else ...
          } // for (j_var)
          count_i_a++ ;
        } else {
          B_b.row(count_i_b) = B_r.row(i_var) ;
          int count_j_b = 0 ;
          for (int j_var=0; j_var<Data.p_y; j_var++){
            if ( loc_vec(j_var)==0 ){
              Sigma_bb(count_i_b,count_j_b) = Sigma_r(i_var,j_var) ;
              count_j_b++ ;
            } // if (loc_vec(j_var))
          } // for (j_var)
          count_i_b++ ;
        } // if (loc_vec==1) else ...
      } // for (i_var)
      arma::mat Sigma_bb_inv = Sigma_bb.i() ;

      where_we_are = "184" ;
      
      arma::vec y_rj_star_vec(n_r); arma::mat X_r(Data.p_x_star,n_r) ;
      int count_i = 0 ;

      for (int i_sample=0; i_sample<Data.n_sample; i_sample++){

        if (r_i_vec(i_sample)==r){

          arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
          arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
          arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
          arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
          double y_a = y_i_vec(j) ; arma::vec y_b = arma::vec(n_b) ;
					arma::rowvec A_i_subvec_a = A_i_mat.row(j) ; arma::mat A_i_submat_b = arma::mat(n_b,p_resp) ;
          int count_i_b = 0 ;
          for (int i_var=0; i_var<Data.p_y; i_var++){
            if ( loc_vec(i_var)==0 ){
              y_b(count_i_b) = y_i_vec(i_var) ;
              A_i_submat_b.row(count_i_b) = A_i_mat.row(i_var) ;
              count_i_b++ ;
            } // if (loc_vec==1) else ...
          } // for (i_var)

          arma::vec mu_i_star ;
					mu_i_star = Sigma_ab * Sigma_bb_inv * ( y_b - B_b * x_i_star_vec - A_i_submat_b * delta_vec ) ; // causal
					arma::vec temp_vec = A_i_subvec_a * delta_vec ; 
          y_rj_star_vec(count_i) = y_a - mu_i_star(0) - temp_vec(0) ; // causal
          X_r.col(count_i) = x_i_star_vec ;
          count_i++ ;

        } // if (==r)

      } // for (i_sample)

      where_we_are = "218" ;

      arma::mat temp_mat = Sigma_ab * Sigma_bb_inv * Sigma_ab.t() ;
      double sig2_star = Sigma_aa(0,0) - temp_mat(0,0) ;
      arma::mat Cov_star_inv = (1.0/sig2_star)*X_r*X_r.t() + T_mat ;
      arma::mat Cov_star = Cov_star_inv.i() ;
      arma::vec temp_vec = (1.0/sig2_star)*X_r*y_rj_star_vec + T_mat*theta_mat.row(j).t() ;
      arma::vec mean_star = Cov_star * temp_vec ;
      arma::mat UT_Cov_star = arma::chol(Cov_star) ;
      arma::vec beta_rj = rMVN_UT_chol_fn( mean_star, UT_Cov_star ) ;
      Beta_cube( arma::span(j,j), arma::span(0,Data.p_x_star-1), arma::span(r,r) ) = beta_rj ;

    } // for (j)
  } // for (r)

} // void CParam::S1_Beta_cube

void CParam::S2_Sigma_cube(CData &Data){
  where_we_are = "S2_Sigma_cube" ;
	
  for (int r=0; r<Data.R; r++){

    arma::mat B_r = Beta_cube.slice(r) ;  int n_r = n_r_vec(r) ;
    arma::mat SS_y_Bx = arma::zeros<arma::mat>(Data.p_y,Data.p_y) ;

    for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
      if (r_i_vec(i_sample)==r){
        arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
        arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
        arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
        arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
				arma::vec y_i_Bx = y_i_vec - B_r * x_i_star_vec - A_i_mat * delta_vec ; // causal
        SS_y_Bx = SS_y_Bx + y_i_Bx * y_i_Bx.t() ;
      } // if (==r)
    } // for (i_sample)

    int nu_star = Data.nu_sigma + n_r ;
    arma::mat Phi_star = Phi_mat + SS_y_Bx ;
    arma::mat UT_Phi_star = arma::chol(Phi_star) ;
    arma::mat Sigma_r = rIW_UT_chol_fn( nu_star, UT_Phi_star ) ;
    UT_Sigma_cube.slice(r) = arma::chol(Sigma_r) ;

  } // for (r)

} // void CParam::S2_Sigma_cube

void CParam::S3_theta_mat(CData &Data){
  where_we_are = "S3_theta_mat" ;

  for (int j=0; j<Data.p_y; j++){
    for (int l=0; l<Data.p_x_star; l++){
      double sum_beta_jrl = 0 ;
      for (int r=0; r<Data.R; r++){
        sum_beta_jrl = sum_beta_jrl + Beta_cube(j,l,r) ;
      }
      double sig2_star = 1.0 / (Data.R/tau_inv_diag_vec(l) + 1.0/(Data.b_theta*Data.b_theta))  ;
      double mean_star = sig2_star / tau_inv_diag_vec(l) * sum_beta_jrl ; // tau_l
      arma::vec RandVec = Rcpp::rnorm(1,mean_star,sqrt(sig2_star)) ;
      theta_mat(j,l) = RandVec(0) ;
    } // for (l)
  } // for (j)

} // void CParam::S3_theta_mat

void CParam::S4_Phi_mat(CData &Data){
  where_we_are = "S4_Phi_mat" ;

  arma::mat Sum_inv_Sigma_r = arma::zeros<arma::mat>(Data.p_y,Data.p_y) ;
  for (int r=0; r<Data.R; r++){
    arma::mat UT_r = UT_Sigma_cube.slice(r) ;
    arma::mat inv_UT_r = UT_r.i() ;
    Sum_inv_Sigma_r = Sum_inv_Sigma_r + inv_UT_r * inv_UT_r.t() ; // Sigma^-1 = U^-1 L^-1
  } // for (r)
  int nu_star = Data.R * Data.nu_sigma + Data.nu_phi ;
  arma::mat V = Sum_inv_Sigma_r + Data.Phi_0_mat.i() ;
  arma::mat UT = chol(V) ; arma::mat inv_UT = UT.i() ; // U_(V^-1) = L^-1 = (U^-1)^T
  Phi_mat = rWishart_UT_chol_fn( nu_star, inv_UT.t()  ) ;

} // void CParam::S4_Phi_mat

void CParam::S5_psi_cube(CData &Data){
  where_we_are = "S5_psi_cube" ;

  for (int l=0; l<Data.p_x; l++){
    for (int s=0; s<Data.S; s++){
      arma::vec psi_star_vec(Data.D_l_vec(l)) ; psi_star_vec.fill(Data.psi_0) ;
      for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
        if (s_i_vec(i_sample)==s){
          psi_star_vec(X_mat_imp(i_sample,l)) = psi_star_vec(X_mat_imp(i_sample,l)) + 1 ;
        }
        arma::vec psi_ls_vec = rDirichlet_fn(psi_star_vec) ;
        psi_cube( arma::span(l,l), arma::span(s,s), arma::span(0,Data.D_l_vec(l)-1) ) = psi_ls_vec ;
      } // for (i)
    } // for (s)
  } // for (l)

} // void CParam::S5_psi_cube

void CParam::S6a_log_pi_vec(CData &Data){
  where_we_are = "S6a_log_pi_vec" ;

  arma::vec nu_short(Data.K-1) ;
  nu_short.fill(0.1) ; double Sum_n_m = sum(n_k_vec) ;
  for (int k=0; k<(Data.K-1); k++) {
    double one_tilde = 1.0 + n_k_vec(k) ;
    Sum_n_m = Sum_n_m - n_k_vec(k) ;
    // start from Sum_n_m - n_k_vec_1 when k=1
    // ->  Sum_n_m - sum(n_k_vec_1 + n_k_vec_2) when k=2 -> ...
    // Sum_n_m - sum(n_k_vec_1 + ... + n_k_vec(k))) i.e. sum_{g=k+1}^K n_k_vec_g
    double alpha_K_tilde = alpha_K + Sum_n_m ;
    arma::vec RandVec = Rcpp::rbeta( 1, one_tilde, alpha_K_tilde ) ;
    nu_short(k) = RandVec(0) ;
  }
  double Sum_logOneMinusVg = 0.0 ;
  for (int k=0; k<(Data.K-1); k++) {
    log_pi_vec(k) = log(nu_short(k)) + Sum_logOneMinusVg ;
    Sum_logOneMinusVg = Sum_logOneMinusVg + log(1.0 - nu_short(k)) ;
  }
  log_pi_vec(Data.K-1) = Sum_logOneMinusVg ;

} // void CParam::S6a_log_pi_vec()

void CParam::S6b_alpha_K(CData &Data){
  where_we_are = "S6b_alpha_K" ;

  double a_tilde = Data.a_K + Data.K - 1.0 ;
  double b_tilde = Data.b_K - log_pi_vec(Data.K-1) ;
  arma::vec RandVec = Rcpp::rgamma(1, a_tilde, 1.0/b_tilde ) ; // Note that b in Rcpp::rgamma(a,b) is scale, i.e., its mean is ab, NOT a/b
  alpha_K = RandVec(0) ;

} // void CParam::S6b_alpha_K

void CParam::S6c_k_i_vec(CData &Data){
  where_we_are = "S6c_k_i_vec" ;

  n_k_vec = arma::zeros<arma::vec>(Data.K) ;
  n_k_r_mat = arma::zeros<arma::mat>(Data.K, Data.R) ;  n_k_s_mat = arma::zeros<arma::mat>(Data.K, Data.S) ;

  for (int i_sample=0; i_sample < Data.n_sample; i_sample++) {

    int r_i = r_i_vec(i_sample) ;  int s_i = s_i_vec(i_sample) ;
    arma::vec log_Num(Data.K);
    for (int k=0; k<Data.K; k++) {
      log_Num(k) = log_pi_vec(k) + log_eta_mat(k,r_i) + log_lambda_mat(k,s_i) ;
    }
    double max_log_Num = log_Num.max() ;
    arma::vec pi_star_unnorm = arma::zeros<arma::vec>(Data.K) ;
    for (int k=0; k<Data.K; k++) {
      pi_star_unnorm(k) = exp( log_Num(k)-max_log_Num ) ;
    }
    arma::vec pi_star = (1.0/sum(pi_star_unnorm)) * pi_star_unnorm ;
    k_i_vec(i_sample) = rdiscrete_fn( pi_star );

    int k_i = k_i_vec(i_sample) ;
    n_k_vec(k_i) = n_k_vec(k_i) + 1 ;
    n_k_r_mat(k_i,r_i) = n_k_r_mat(k_i,r_i) + 1 ; n_k_s_mat(k_i,s_i) = n_k_s_mat(k_i,s_i) + 1 ;

  } // for (int i_sample)

} // void CParam::S6c_k_i_vec(CData &Data)

void CParam::S7a_log_eta_mat(CData &Data){
  where_we_are = "S7a_log_eta_mat" ;

  for (int k=0; k<Data.K; k++){

      arma::vec n_r_given_k_vec = n_k_r_mat.row(k).t() ;
      arma::vec nu_short = arma::zeros<arma::vec>(Data.R-1) ;
      double Sum_n_m = sum(n_r_given_k_vec) ;
      for (int r=0; r<(Data.R-1); r++) {
        double one_tilde = 1.0 + n_r_given_k_vec(r) ;
        Sum_n_m = Sum_n_m - n_r_given_k_vec(r) ;
        // start from Sum_n_m - n_r_vec_1 when r=1
        // ->  Sum_n_m - sum(n_r_vec_1 + n_r_vec_2) when r=2 -> ...
        // Sum_n_m - sum(n_r_vec_1 + ... + n_r_vec(r))) i.e. sum_{g=r+1}^K n_r_vec_g
        double alpha_R_tilde = alpha_R + Sum_n_m ;
        arma::vec RandVec = Rcpp::rbeta( 1, one_tilde, alpha_R_tilde ) ;
        nu_short(r) = RandVec(0) ;
      }
      double Sum_logOneMinusVg = 0.0 ;
    for (int r=0; r<(Data.R-1); r++) {
        log_eta_mat(k,r) = log(nu_short(r)) + Sum_logOneMinusVg ;
        Sum_logOneMinusVg = Sum_logOneMinusVg + log(1.0 - nu_short(r)) ;
      }
      log_eta_mat(k,Data.R-1) = Sum_logOneMinusVg ;

  } // for (k)

} // void CParam::S7a_log_pi_vec()

void CParam::S7b_alpha_R(CData &Data){
  where_we_are = "S7b_alpha_R" ;

  double a_tilde = Data.a_R ; // + 1.0 ;
  double b_tilde = Data.b_R  ;
  for (int k=0; k<Data.K; k++){
    if (n_k_vec(k)>0){
      a_tilde = a_tilde + (Data.R-1) ;
      b_tilde = b_tilde - log_eta_mat(k,Data.R-1) ;
    }
  }
  arma::vec RandVec = Rcpp::rgamma(1, a_tilde, 1.0/b_tilde ) ; // Note that b in Rcpp::rgamma(a,b) is scale, i.e., its mean is ab, NOT a/b
  alpha_R = RandVec(0) ;

} // void CParam::S7b_alpha_R

void CParam::S7c_r_i_vec(CData &Data){
  where_we_are = "S7c_r_i_vec" ;

  n_r_vec = arma::zeros<arma::vec>(Data.R) ;
  n_k_r_mat = arma::zeros<arma::mat>(Data.K, Data.R) ;

  for (int i_sample=0; i_sample < Data.n_sample; i_sample++) {

    int k_i = k_i_vec(i_sample) ;
    arma::vec log_DEN = arma::zeros<arma::vec>(Data.R);
    arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
    arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
    arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
    arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
    for (int r=0; r<Data.R; r++) {
      arma::mat B_r = Beta_cube.slice(r) ;
      log_DEN(r) = log_eta_mat(k_i,r) ;
      log_DEN(r) = log_DEN(r) + log_dMVN_UT_chol_fn( y_i_vec, B_r * x_i_star_vec + A_i_mat * delta_vec, UT_Sigma_cube.slice(r) ) ;
      // causal
    }
    double max_log_DEN = log_DEN.max() ;
    arma::vec eta_star_unnorm = arma::zeros<arma::vec>(Data.R) ;
    for (int r=0; r<Data.R; r++){
      eta_star_unnorm(r) = exp( log_DEN(r)-max_log_DEN ) ;
    }
    arma::vec eta_star = (1.0/sum(eta_star_unnorm)) * eta_star_unnorm ;
    r_i_vec(i_sample) = rdiscrete_fn( eta_star );

    int r_i = r_i_vec(i_sample) ;
    n_r_vec(r_i) = n_r_vec(r_i) + 1 ;
    n_k_r_mat(k_i,r_i) = n_k_r_mat(k_i,r_i) + 1 ;

  } // for (int i_sample)

} // void CParam::S7c_r_i_vec(CData &Data)

void CParam::S8a_log_lambda_mat(CData &Data){
  where_we_are = "S8a_log_lambda_mat" ;

  for (int k=0; k<Data.K; k++){

    arma::vec n_s_given_k_vec = n_k_s_mat.row(k).t() ;
    arma::vec nu_short(Data.S-1) ;
    nu_short.fill(0.1) ; double Sum_n_m = sum(n_s_given_k_vec) ;
    for (int s=0; s<(Data.S-1); s++) {
      double one_tilde = 1.0 + n_s_given_k_vec(s) ;
      Sum_n_m = Sum_n_m - n_s_given_k_vec(s) ;
      // start from Sum_n_m - n_r_vec_1 when r=1
      // ->  Sum_n_m - sum(n_r_vec_1 + n_r_vec_2) when r=2 -> ...
      // Sum_n_m - sum(n_r_vec_1 + ... + n_r_vec(r))) i.e. sum_{g=r+1}^K n_r_vec_g
      double alpha_S_tilde = alpha_S + Sum_n_m ;
      arma::vec RandVec = Rcpp::rbeta( 1, one_tilde, alpha_S_tilde ) ;
      nu_short(s) = RandVec(0) ;
    }
    double Sum_logOneMinusVg = 0.0 ;
    for (int s=0; s<(Data.S-1); s++) {
      log_lambda_mat(k,s) = log(nu_short(s)) + Sum_logOneMinusVg ;
      Sum_logOneMinusVg = Sum_logOneMinusVg + log(1.0 - nu_short(s)) ;
    }
    log_lambda_mat(k,Data.S-1) = Sum_logOneMinusVg ;

  } // for (k)

} // void CParam::S8a_log_pi_vec()

void CParam::S8b_alpha_S(CData &Data){
  where_we_are = "S8b_alpha_S" ;

  double a_tilde = Data.a_S + 1.0 ;
  double b_tilde = Data.b_S  ;
  for (int k=0; k<Data.K; k++){
    if (n_k_vec(k)>0){
      a_tilde = a_tilde + (Data.S-1) ;
      b_tilde = b_tilde - log_lambda_mat(k,Data.S-1) ;
    }
  }
  arma::vec RandVec = Rcpp::rgamma(1, a_tilde, 1.0/b_tilde ) ; // Note that b in Rcpp::rgamma(a,b) is scale, i.e., its mean is ab, NOT a/b
  alpha_S = RandVec(0) ;

} // void CParam::S8b_alpha_S

void CParam::S8c_s_i_vec(CData &Data){
  where_we_are = "S8c_s_i_vec" ;

  n_s_vec = arma::zeros<arma::vec>(Data.S) ;
  n_k_s_mat = arma::zeros<arma::mat>(Data.K, Data.S) ;

  for (int i_sample=0; i_sample < Data.n_sample; i_sample++) {

    int k_i = k_i_vec(i_sample) ;
    arma::vec log_DEN(Data.S);
    arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
    for (int s=0; s<Data.S; s++) {
      log_DEN(s) = log_lambda_mat(k_i,s) ;
      for (int l=0; l<Data.p_x; l++){
        int x_il = x_i_vec(l) ; // 0 ~ D_l_vec(l)-1 ;
        log_DEN(s) = log_DEN(s) + log(psi_cube(l,s,x_il)) ;
      }
    }
    double max_log_DEN = log_DEN.max() ;
    arma::vec lambda_star_unnorm = arma::zeros<arma::vec>(Data.S) ;
    for (int s=0; s<Data.S; s++){
      lambda_star_unnorm(s) =  exp( log_DEN(s)-max_log_DEN ) ;
    }
    arma::vec lambda_star = (1.0/sum(lambda_star_unnorm)) * lambda_star_unnorm ;
    s_i_vec(i_sample) = rdiscrete_fn( lambda_star );

    int s_i = s_i_vec(i_sample) ;
    n_s_vec(s_i) = n_s_vec(s_i) + 1 ;
    n_k_s_mat(k_i,s_i) = n_k_s_mat(k_i,s_i) + 1 ;

  } // for (int i_sample)

} // void CParam::S8c_s_i_vec(CData &Data)

void CParam::S9_tau_inv_diag_vec(CData &Data){
  where_we_are = "S9_tau_inv_diag_vec" ;

  for (int l=0; l<Data.p_x_star; l++){

    double SS_b_theta = 0.0 ;
    for (int j=0; j<Data.p_y; j++){
      for (int r=0; r<Data.R; r++){
        double dev_b_theta = Beta_cube(j,l,r) - theta_mat(j,l) ;
        SS_b_theta = SS_b_theta + dev_b_theta*dev_b_theta ;
      }
    }
    double a_star = Data.a_tau + 0.5 * Data.p_y * Data.R ;
    double b_star = Data.b_tau + 0.5 * SS_b_theta ;
    arma::vec RandVec = Rcpp::rgamma(1, a_star, 1.0/b_star ) ;
    tau_inv_diag_vec(l) = 1.0/RandVec(0) ;

  } // for (l)

} // void CParam::S8c_s_i_vec(CData &Data)


void CParam::S_impute_X_mat(CData &Data){
  where_we_are = "S_impute_X_mat" ;
	
  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){

    arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
    arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
    arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
    int r_i = r_i_vec(i_sample) ; int s_i = s_i_vec(i_sample) ;
    arma::mat B_r_i = Beta_cube.slice(r_i) ;
    arma::mat UT_Sigma_r_i = UT_Sigma_cube.slice(r_i) ;

    for (int l=0; l<Data.p_x; l++){
      if (Data.X_NA_mat(i_sample,l)==1){
        arma::vec log_DEN = arma::zeros<arma::vec>(Data.D_l_vec(l)) ;
        for (int i_d=0; i_d<Data.D_l_vec(l); i_d++){
          arma::vec x_i_prop = x_i_vec ; x_i_prop(l) = i_d ;
          arma::vec x_i_star_prop = x_to_x_star_fn(x_i_prop, Data) ;
          log_DEN(i_d) = log(psi_cube(l,s_i,i_d)) + log_dMVN_UT_chol_fn(y_i_vec, B_r_i * x_i_star_prop + A_i_mat * delta_vec, UT_Sigma_r_i) ;
        }
        double max_log_DEN = log_DEN.max() ;
        arma::vec psi_star_unnorm = arma::zeros<arma::vec>(Data.D_l_vec(l)) ;
        for (int i_d=0; i_d<Data.D_l_vec(l); i_d++){
          psi_star_unnorm(i_d) =  exp( log_DEN(i_d)-max_log_DEN ) ;
        }
        arma::vec psi_star = (1.0/sum(psi_star_unnorm)) * psi_star_unnorm ;
        X_mat_imp(i_sample,l) = rdiscrete_fn( psi_star );
      } // if (NA)
    } // for (l)

  } // for (int i_sample)

} // CParam::S_impute_X_mat

void CParam::S_impute_Y_mat(CData &Data){
  where_we_are = "S_impute_Y_mat" ;

  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){

    arma::vec s_i = Data.Y_NA_mat.row(i_sample).t() ;

    if ( sum(s_i)>0 ){

      arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
      arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
      arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
      arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
      int r_i = r_i_vec(i_sample) ;
      arma::mat B_r_i = Beta_cube.slice(r_i) ;
      arma::vec mu_i = B_r_i * x_i_star_vec + A_i_mat * delta_vec ;
      arma::mat UT_Sigma_r_i = UT_Sigma_cube.slice(r_i) ;
      arma::mat Sigma_i = UT_Sigma_r_i.t()*UT_Sigma_r_i ;

      int n_a = sum(s_i) ; int n_b = Data.p_y - n_a ;
      arma::vec mu_a = arma::vec(n_a) ; arma::vec mu_b = arma::vec(n_b) ; arma::vec y_b = arma::vec(n_b) ;
      arma::mat Sigma_aa = arma::mat(n_a,n_a) ; arma::mat Sigma_ab = arma::mat(n_a,n_b) ; arma::mat Sigma_bb = arma::mat(n_b,n_b) ;

      int count_i_a = 0 ; int count_i_b = 0 ;
      for (int i_var=0; i_var<Data.p_y; i_var++){
        if ( s_i(i_var)==1 ){
          mu_a(count_i_a) = mu_i(i_var) ;
          int count_j_a = 0 ; int count_j_b = 0 ;
          for (int j_var=0; j_var<Data.p_y; j_var++){
            if ( s_i(j_var)==1 ){
              Sigma_aa(count_i_a,count_j_a) = Sigma_i(i_var,j_var) ;
              count_j_a++ ;
            } else {
              Sigma_ab(count_i_a,count_j_b) = Sigma_i(i_var,j_var) ;
              count_j_b++ ;
            } // if (s_i(j_var)) else ...
          } // for (j_var)
          count_i_a++ ;
        } else {
          mu_b(count_i_b) = mu_i(i_var) ; y_b(count_i_b) = y_i_vec(i_var) ;
          int count_j_b = 0 ;
          for (int j_var=0; j_var<Data.p_y; j_var++){
            if ( s_i(j_var)==0 ){
              Sigma_bb(count_i_b,count_j_b) = Sigma_i(i_var,j_var) ;
              count_j_b++ ;
            } // if (s_i(j_var))
          } // for (j_var)
          count_i_b++ ;
        } // if (s_i==1) else ...
      } // for (i_var)

      arma::mat Sigma_bb_inv = Sigma_bb.i() ;
      arma::vec mu_a_star = mu_a + Sigma_ab * Sigma_bb_inv * (y_b-mu_b) ;
      arma::mat Sigma_a_star = Sigma_aa - Sigma_ab * Sigma_bb_inv * Sigma_ab.t() ;
      arma::mat UT_chol_a = arma::chol(Sigma_a_star) ;
      arma::vec y_a = rMVN_UT_chol_fn( mu_a_star, UT_chol_a ) ;
      arma::vec y_i_q = y_i_vec ;
      count_i_a = 0 ;
      bool within_LU = true ; // ver 1.1.0
      for (int i_var=0; i_var<Data.p_y; i_var++){
        if ( s_i(i_var)==1 ){
          if ( (y_a(count_i_a)>=Data.bound_L(i_var)) && (y_a(count_i_a)<=Data.bound_U(i_var)) ){ // ver 1.1.0
            y_i_q(i_var) = y_a(count_i_a) ; // ver 1.1.0
          } else {
            within_LU = false ;
          } // ver 1.1.0
          count_i_a++ ;
        } // if (s_i==1)
      } // for(i_var)

      if ( within_LU==true ){
        Y_mat_imp.row(i_sample) =  y_i_q.t() ;
      }

    } // if ( sum(s_i)>0 )

  } // for (int i_sample)

} // CParam::S_impute_Y_mat


void CParam::S_update_delta(CData &Data){
	
  where_we_are = "S_update_delta" ;
	
	arma::mat inv_b_delta_mat = arma::zeros<arma::mat>(p_resp,p_resp) ; 
	inv_b_delta_mat.diag().fill(1.0/(Data.b_delta*Data.b_delta)) ; 
  arma::vec SSxy = arma::zeros<arma::vec>(p_resp) ; arma::mat SSxx = arma::zeros<arma::mat>(p_resp,p_resp) ;
  arma::vec loc_vec = arma::zeros<arma::vec>(Data.p_y) ; 
	for (int i_resp=0; i_resp<p_resp; i_resp++) loc_vec(i_resp) = 1 ; 

  for (int r=0; r<Data.R; r++){

    arma::mat Sigma_r = UT_Sigma_cube.slice(r).t() * UT_Sigma_cube.slice(r) ;
    arma::mat B_r = Beta_cube.slice(r) ;

    int n_a = sum(loc_vec) ; int n_b = Data.p_y - n_a ; 
    arma::mat Sigma_aa = arma::mat(n_a,n_a) ; arma::mat Sigma_ab = arma::mat(n_a,n_b) ; arma::mat Sigma_bb = arma::mat(n_b,n_b) ;
    arma::mat B_a = arma::mat(n_a,Data.p_x_star) ; arma::mat B_b = arma::mat(n_b,Data.p_x_star) ;
    int count_i_a = 0 ; int count_i_b = 0 ;
    for (int i_var=0; i_var<Data.p_y; i_var++){
      if ( loc_vec(i_var)==1 ){
				B_a.row(count_i_a) = B_r.row(i_var) ;
        int count_j_a = 0 ; int count_j_b = 0 ;
        for (int j_var=0; j_var<Data.p_y; j_var++){
          if ( loc_vec(j_var)==1 ){
            Sigma_aa(count_i_a,count_j_a) = Sigma_r(i_var,j_var) ;
            count_j_a++ ;
          } else {
            Sigma_ab(count_i_a,count_j_b) = Sigma_r(i_var,j_var) ;
            count_j_b++ ;
          } // if 
        } // for 
        count_i_a++ ;
      } else {
        B_b.row(count_i_b) = B_r.row(i_var) ;
        int count_j_b = 0 ;
        for (int j_var=0; j_var<Data.p_y; j_var++){
          if ( loc_vec(j_var)==0 ){
            Sigma_bb(count_i_b,count_j_b) = Sigma_r(i_var,j_var) ;
            count_j_b++ ;
          } // if
        } // for 
        count_i_b++ ;
      } // if ... else ...
    } // for (i_var)
    arma::mat Sigma_bb_inv = Sigma_bb.i() ;
    arma::mat sig2_r1_star = Sigma_aa - Sigma_ab * Sigma_bb_inv * Sigma_ab.t() ;
		arma::mat inv_sig2_r1_star = sig2_r1_star.i() ; 

    for (int i_sample=0; i_sample<Data.n_sample; i_sample++){

      if (r_i_vec(i_sample)==r){

        arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
        arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
        arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
        arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;

        arma::vec y_a = arma::vec(n_a) ; arma::vec y_b = arma::vec(n_b) ;
				arma::mat A_i_submat_a = arma::mat(n_a,p_resp) ; arma::mat A_i_submat_b = arma::mat(n_b,p_resp) ;
        int count_i_a = 0 ; int count_i_b = 0 ;
        for (int i_var=0; i_var<Data.p_y; i_var++){
          if ( loc_vec(i_var)==0 ){
            y_b(count_i_b) = y_i_vec(i_var) ;
            A_i_submat_b.row(count_i_b) = A_i_mat.row(i_var) ;
            count_i_b++ ;
          } else {
            y_a(count_i_a) = y_i_vec(i_var) ;
            A_i_submat_a.row(count_i_a) = A_i_mat.row(i_var) ;
            count_i_a++ ;
          } // if (loc_vec==1) else ...
        } // for (i_var)

        arma::vec temp_vec = y_b - B_b * x_i_star_vec - A_i_submat_b * delta_vec ;
        arma::vec y_tilde_i1 = y_a - B_a * x_i_star_vec - Sigma_ab * Sigma_bb_inv * temp_vec ;
        SSxy = SSxy + A_i_submat_a * inv_sig2_r1_star * y_tilde_i1 ;
        SSxx = SSxx + A_i_submat_a * inv_sig2_r1_star ;

      } // if (r_i==r)
    } // for (i_sample)

  } // for (r)

	arma::mat inv_sig2_star = SSxx + inv_b_delta_mat ; arma::mat sig2_star_mat = inv_sig2_star.i() ;
	arma::vec mean_star = sig2_star_mat * SSxy ;
	arma::mat tempUT = chol(sig2_star_mat) ; 
	delta_vec = rMVN_UT_chol_fn( mean_star, tempUT ) ; 
	
} // CParam::S_update_delta

void CParam::S_upated_log_prob(CData &Data){

  log_prob = 0 ;

  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){

    arma::vec y_i_vec = Y_mat_imp.row(i_sample).t() ;
    arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
    arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
    arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
    int r_i = r_i_vec(i_sample) ;
    arma::mat B_r_i = Beta_cube.slice(r_i) ;
    arma::vec mu_i = B_r_i * x_i_star_vec + A_i_mat * delta_vec ;
    arma::mat UT_Sigma_r_i = UT_Sigma_cube.slice(r_i) ;

    log_prob = log_prob + log_dMVN_UT_chol_fn(y_i_vec, mu_i, UT_Sigma_r_i) ;

  } // for (i_sample)

} // CParam::S_upated_log_prob

void CParam::compute_pred_Y(CData &Data){

  pred_Y = Y_mat_imp.rows(0,Data.n_sample-1) ;

  for (int i_sample=0; i_sample<Data.n_sample; i_sample++){

    arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
    arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
    arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
    int r_i = r_i_vec(i_sample) ;
    arma::mat B_r_i = Beta_cube.slice(r_i) ;

    arma::vec mu_i = B_r_i * x_i_star_vec + A_i_mat * delta_vec ;
    arma::mat UT_Sigma_r_i = UT_Sigma_cube.slice(r_i) ;

    arma::vec temp_vec = rMVN_UT_chol_fn(mu_i, UT_Sigma_r_i) ;
    pred_Y.row(i_sample) = temp_vec.t() ;

  } // for (i_sample)

} // void CParam::compute_pred_Y(CData &Data)
	
	
	
	

// void CParam::S_add_test_Y_std_synt(CData &Data){
//
//   where_we_are = "S_add_test_Y_std_synt" ;
//
//   test_Y_std_synt = arma::zeros(Data.n_sample,Data.p_y) ;
//
//   for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
//
//     arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
//     arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
//     int r_i = r_i_vec(i_sample) ;
//     arma::mat B_r_i = Beta_cube.slice(r_i) ;
//     arma::vec mean_star = B_r_i * x_i_star_vec ;
//
//     arma::mat UT_Sigma_r_i = UT_Sigma_cube.slice(r_i) ;
//     arma::vec y_std_synt_i = rMVN_UT_chol_fn( mean_star, UT_Sigma_r_i ) ;
//
//     test_Y_std_synt.row(i_sample) = y_std_synt_i.t() ;
//
//   } // for (int i_sample)
//
// } // CParam::S_add_test_Y_std_synt


// void CParam::S10_DA(CData &Data){
// 
//   where_we_are = "S10_DA" ;
//
//   arma::vec r_i_vec = r_i_vec.rows(0,Data.n_sample-1) ;
//   arma::vec s_i_vec = s_i_vec.rows(0,Data.n_sample-1) ;
//   arma::vec k_i_vec = k_i_vec.rows(0,Data.n_sample-1) ;
//
//   arma::mat X_mat = X_mat_imp.rows(0,Data.n_sample-1) ;
//   arma::mat Y_mat = Y_mat_imp.rows(0,Data.n_sample-1) ;
//
//   int count_out = 0 ;
//   arma::vec r_out_plus_dummy(1) ; r_out_plus_dummy.fill(999) ; // The first row has dummy value (999), followed by r_out
//   arma::vec s_out_plus_dummy(1) ; s_out_plus_dummy.fill(999) ; // The first row has dummy value (999), followed by r_out
//   arma::vec k_out_plus_dummy(1) ; k_out_plus_dummy.fill(999) ; // The first row has dummy value (999), followed by r_out
//   arma::mat Y_mat_out_plus_dummy(1, Data.p_y) ; Y_mat_out_plus_dummy.fill(999) ;
//   arma::mat X_mat_out_plus_dummy(1, Data.p_x) ; X_mat_out_plus_dummy.fill(999) ;
//   arma::mat Data.A_ij_cube_out_plus_dummy(1, Data.p_y) ; Data.A_ij_cube_out_plus_dummy.fill(999) ;
//
//   arma::vec temp_vec(1) ;
//
//   for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
//
//     where_we_are = "592" ;
//
//     arma::vec x_i_vec = X_mat_imp.row(i_sample).t() ;
//     arma::vec x_i_star_vec = x_to_x_star_fn(x_i_vec, Data) ;
//     arma::mat A_i_mat = Data.A_ij_cube.slice(i_sample) ;
//     int r_i = r_i_vec(i_sample) ;
//     arma::mat B_r_i = Beta_cube.slice(r_i) ;
//     arma::vec mu_i = B_r_i * x_i_star_vec + delta * A_i_vec ;
//     arma::mat UT_Sigma_r_i = UT_Sigma_cube.slice(r_i) ;
//
//     int count_i_out = 0 ; int count_i_in = 0 ;
//
//     while ( (count_i_in<=0) && (count_i_out<=1) ){
//
//       arma::vec y_i_q = rMVN_UT_chol_fn(mu_i, UT_Sigma_r_i) ;
//       bool within_LU = true ;
//       for (int i_var=0; i_var<Data.p_y; i_var++){
//         if ( (y_i_q(i_var)<Data.bound_L(i_var)) || (y_i_q(i_var)>Data.bound_U(i_var)) ){
//           within_LU = false ;
//         }
//       }
//
//       if ( within_LU==false ){
//         count_out++ ; count_i_out++ ;
//         temp_vec(0) = r_i ; r_out_plus_dummy.insert_rows( count_out, temp_vec ) ;
//         temp_vec(0) = s_i_vec(i_sample) ; s_out_plus_dummy.insert_rows( count_out, temp_vec ) ;
//         temp_vec(0) = k_i_vec(i_sample) ; k_out_plus_dummy.insert_rows( count_out, temp_vec ) ;
//         Y_mat_out_plus_dummy.insert_rows( count_out, y_i_q.t() ) ;
//         X_mat_out_plus_dummy.insert_rows( count_out, X_mat_imp.row(i_sample) ) ;
//         Data.A_ij_cube_out_plus_dummy.insert_rows( count_out, Data.A_ij_cube.row(i_sample) ) ;
//       } else {
//         count_i_in++ ;
//       }
//
//     } // while
//
//     where_we_are = "622" ;
//
//   } // for (i_sample < Data.n_sample)
//
//   where_we_are = "626" ;
//
//   // std::cout << count_out << std::endl ;
//
//   if (count_out>0){
//
//     r_out_plus_dummy.shed_row(0) ; s_out_plus_dummy.shed_row(0) ; k_out_plus_dummy.shed_row(0) ;
//     Y_mat_out_plus_dummy.shed_row(0) ; X_mat_out_plus_dummy.shed_row(0) ; Data.A_ij_cube_out_plus_dummy.shed_row(0) ;
//
//     where_we_are = "629" ;
//
//     Data.n_sample = Data.n_sample + count_out ;
//     r_i_vec = join_vert( r_i_vec, r_out_plus_dummy ) ;
//     s_i_vec = join_vert( s_i_vec, s_out_plus_dummy ) ;
//     k_i_vec = join_vert( k_i_vec, k_out_plus_dummy ) ;
//     Y_mat_imp = join_vert( Y_mat, Y_mat_out_plus_dummy ) ; // concenate two matrices with the same number of columns
//     X_mat_imp = join_vert( X_mat, X_mat_out_plus_dummy ) ; // concenate two matrices with the same number of columns
//     Data.A_ij_cube = join_vert( Data.A_ij_cube, Data.A_ij_cube_out_plus_dummy ) ; // concenate two matrices with the same number of columns
//
//     where_we_are = "639" ;
//
//   } else {
//
//     where_we_are = "649" ;
//
//     Data.n_sample = Data.n_sample ;
//     r_i_vec = r_i_vec ; s_i_vec = s_i_vec ; k_i_vec = k_i_vec ;
//     Y_mat_imp = Y_mat ; X_mat_imp = X_mat ; Data.A_ij_cube = Data.A_ij_cube ;
//
//   } //
//
//   where_we_are = "655" ;
//
//   n_r_vec.fill(0) ; n_s_vec.fill(0) ; n_k_vec.fill(0) ; n_k_r_mat.fill(0) ; n_k_s_mat.fill(0) ;
//   for (int i_sample=0; i_sample<Data.n_sample; i_sample++){
//     int r_i = r_i_vec(i_sample) ; int s_i = s_i_vec(i_sample) ; int k_i = k_i_vec(i_sample) ;
//     n_r_vec(r_i) = n_r_vec(r_i) + 1 ; n_s_vec(s_i) = n_s_vec(s_i) + 1 ; n_k_vec(k_i) = n_k_vec(k_i) + 1 ;
//     n_k_s_mat(k_i,s_i) = n_k_s_mat(k_i,s_i) + 1 ; n_k_r_mat(k_i,r_i) = n_k_r_mat(k_i,r_i) + 1 ;
//   } // i_sample
//
//   where_we_are = "665" ;
//
// } // void CParam::S10_DA(CData &Data){

//////////////////////////////////////
// Functions

arma::vec CParam::cube_to_vec_fn(arma::cube input_cube, int first_row, int last_row, int first_col, int last_col, int first_slice, int last_slice ){
  int diff_row = last_row - first_row ;
  int diff_col = last_col - first_col ;
  int diff_slice = last_slice - first_slice ;
  if ( ( diff_row < 0 ) || ( diff_col < 0 ) || ( diff_slice < 0 ) ) Rcpp::stop("Incorrect input in CParam::cube_to_vec_fn") ;
  if ( ( diff_row > 0 ) && ( diff_col > 0 ) ) Rcpp::stop("Incorrect input in CParam::cube_to_vec_fn") ;
  if ( ( diff_row > 0 ) && ( diff_slice > 0 ) ) Rcpp::stop("Incorrect input in CParam::cube_to_vec_fn") ;
  if ( ( diff_col > 0 ) && ( diff_slice > 0 ) ) Rcpp::stop("Incorrect input in CParam::cube_to_vec_fn") ;
  int size_output = diff_row ;
  if (size_output < diff_col) size_output = diff_col;
  if (size_output < diff_slice) size_output = diff_slice;
  size_output = size_output + 1 ;
  arma::vec output_vec(size_output) ;
  int count_temp = 0 ;
  for (int i_row=first_row; i_row<=last_row; i_row++){
    for (int i_col=first_col; i_col<=last_col; i_col++){
      for (int i_slice=first_slice; i_slice<=last_slice; i_slice++){
        output_vec(count_temp) = input_cube(i_row,i_col,i_slice) ;
        count_temp++ ;
      }
    }
  }
  return output_vec ;
} // CParam::cube_to_vec_fn

arma::vec CParam::x_to_x_star_fn(arma::vec x_vec, CData &Data){
  arma::vec x_star = arma::zeros<arma::vec>(Data.p_x_star) ;
  x_star(0) = 1 ;
  int prev_end_point = 0 ;
  for (int l=0; l<Data.p_x; l++){
    if (x_vec(l)>0) x_star(prev_end_point+x_vec(l)) = 1 ;
    prev_end_point = prev_end_point + Data.D_l_vec(l) - 1 ;
  } // for (l)
  return x_star ;
} // CParam::cube_to_vec_fn


//////////////////////////////////////
// For Rcpp Armadillo
//
// .i() -> inverse of square matrix, same with inv(A) : check sqaure and singular
//  inv(A) -> same with .i() : if use B = inv(A), singluar case returns a bool set to false
//  inv( diagmat(A) ) -> if A is diagonal matrix
//  inv_sympd( A ) -> inverse of symmetric, pd matrix : not check symmetric
//  to solve a system of linear equations, such as Z = inv(X)*Y, using solve() is faster and more accurate
//
//  A.t();    // equivalent to trans(A), but more compact
//
//  psi_cube( arma::span(l,l), arma::span(s,s), arma::span(0,Data.D_l_vec(l)-1) ).fill( 1.0 ) ;
//
//  ** using Rcpp::runif, Rcpp::rbeta, Rcpp::rgamma, Rcpp::rnorm
//      // using R::runif in Rcpp is sometimes unstable
//
//  RandVec = Rcpp::rgamma(1, a, 1.0/b ) ; // for Gamma(a,b) with mean of a/b
//  // Note that b in Rcpp::rgamma(a,b) is scale, i.e., its mean is ab, NOT a/b
//
//  cout::std << " ddd " << cout::endl ;
//  Rprintf("  \n  ") ;
//
//  where_we_are.append("here: ") ;   where_we_are.append( std::to_string( i ) ) ;

//////////////////////////////////////
// Hang Kim's Distribution

// double CParam::log_dMVN_fn(arma::vec x, arma::vec mu, arma::mat sigma_mat){
//   arma::mat UT_chol = arma::chol(sigma_mat) ;
//   return(log_dMVN_UT_chol_fn(x, mu, UT_chol));
//   // This function is checked with "dmvnorm" in mvtnorm package on 2018/01/26
// }

double CParam::log_dMVN_UT_chol_fn(arma::vec x, arma::vec mu, arma::mat UT_chol){
  arma::mat inv_LTchol = UT_chol.i().t() ; // arma::trans( arma::inv( UT_chol )) ;
  int xdim = x.n_rows;
  double constants = -(xdim/2) * std::log(2.0 * M_PI);
  double sum_log_inv_LTchol = arma::sum(log(inv_LTchol.diag()));
  arma::vec z = inv_LTchol * ( x - mu ) ;
  double logout = constants + sum_log_inv_LTchol - 0.5 * arma::sum(z%z) ;
  // %	Schur product: element-wise multiplication of two objects
  // i.e. arma::cum(z%z) = z.t() * z = sum_i z_i^2  // z.t() * z  produces 1 by 1 matrix, so need another line
  return(logout);
  // This function is checked with "dmvnorm" in mvtnorm package on 2018/01/26
} // arma::vec dmvnrm_arma_mc

// arma::vec CParam::rMVN_fn(arma::vec mu_vec, arma::mat Sigma_mat){
//   arma::mat UT_chol = arma::chol(Sigma_mat) ;
//   return(rMVN_UT_chol_fn(mu_vec, UT_chol)) ;
// } // arma::vec CParam::rMVN_fn

arma::vec CParam::rMVN_UT_chol_fn(arma::vec mu, arma::mat UT_chol){
  int n_var = UT_chol.n_rows ;
  arma::vec RandVec = Rcpp::rnorm(n_var,0,1) ;
  arma::mat LT_chol = UT_chol.t() ;
  arma::vec out = mu + LT_chol * RandVec ;
  // MVN // y_vec = a_vec + A * z_vec where Sigma = A A^T
  // Cholesky // Sigma = L L^T = U^T U // arma::chol(Sigma) = U
  return out ;
} // arma::mat rMVN_fn

arma::vec CParam::rDirichlet_fn( arma::vec alpha_vec ){
  int p = alpha_vec.n_rows ; arma::vec y_vec(p) ;
  for (int j=0; j<p; j++){
    arma::vec RandVec = Rcpp::rgamma(1, alpha_vec(j), 1.0 ) ; // Gamma(a_j,1)
    y_vec(j) = RandVec(0) ;
  }
  double sum_y_vec = sum(y_vec) ;
  arma::vec output_vec = (1.0/sum_y_vec) * y_vec ;
  return output_vec ;
} // arma::mat CParam::rDirichlet_fn

arma::mat CParam::rWishart_UT_chol_fn( int nu, arma::mat UT_chol ){
  int p = UT_chol.n_rows ;
  arma::mat S_mat = arma::zeros<arma::mat>(p,p) ;
  for (int l=0; l<nu; l++){
    arma::vec RandVec = Rcpp::rnorm(p,0,1) ;
    arma::vec x_l = UT_chol.t() * RandVec ;
    S_mat = S_mat + x_l * x_l.t() ;
  }
  return S_mat ;
} // arma::mat CParam::rWishart_UT_chol_fn

// arma::mat CParam::rIW_fn( int nu, arma::mat Mat ){
//   arma::mat UT_chol = arma::chol(Mat) ;
//   return rIW_UT_chol_fn(nu, UT_chol) ;
// } // arma::mat CParam::rIW_w_pd_check_fn

arma::mat CParam::rIW_UT_chol_fn( int nu, arma::mat UT_chol ){

  // Draw IW( nu, UT_chol.t() * UT_chol ) // See 37_Matrix_RandomNumber_Rcpp.pdf ; Function checked

  int p = UT_chol.n_rows ;
  arma::mat inv_UT_chol = UT_chol.i() ;
  arma::mat U_mat = arma::zeros<arma::mat>(p,p) ;
  for (int l=0; l<nu; l++){
    arma::vec RandVec = Rcpp::rnorm(p,0,1) ;
    arma::vec x_l = inv_UT_chol * RandVec ;
    U_mat = U_mat + x_l * x_l.t() ;
  }

  arma::mat V_mat = U_mat.i() ;

  // May result in non-positive definite matrix due to a decimal rounding error
  arma::vec diag_lambda_vec; arma::mat Q_mat;
  eig_sym(diag_lambda_vec, Q_mat, V_mat);
  
  if (diag_lambda_vec.min() < 1e-7){
    std::cout << "Warn: eigenvalue in generating rIW_UT_chol_fn is smaller than 1e-7" << std::endl ; 
    for (int i_dim=0; i_dim<p; i_dim++){
      if ( diag_lambda_vec(i_dim) < 1e-7 ) diag_lambda_vec(i_dim) = 1e-7 ;
    }
    V_mat = Q_mat * diagmat(diag_lambda_vec) * Q_mat.t() ;
    eig_sym(diag_lambda_vec, Q_mat, V_mat) ;
  } // if 

  return V_mat ;

} // arma::mat CParam::rIW_UT_chol_fn

int CParam::rdiscrete_fn(arma::vec Prob){
  // generate an integer from 0 to (max_no-1) with Prob
  if ( fabs( sum(Prob)-1.0 ) > 1e-10 ) {
    // std::cout << "IterCount = " <<  IterCount << std::endl ;
    // std::cout << "Program stops at the step/line: " <<  current_procedure << std::endl ;
    std::cout << "Prob = " << std::endl ;
    std::cout << Prob.t() << std::endl ;
    std::cout << "sum(Prob) = " << sum(Prob) << std::endl ;
    std::cout << "sum(Prob) != 1 in rdiscrete_fn" << std::endl ;
    Rcpp::stop("sum(Prob) != 1 in rdiscrete_fn") ;
  }
  int n_vec = Prob.n_rows ; arma::vec CumProb = Prob ;
  for (int i=1; i<n_vec; i++) {
    CumProb(i) = CumProb(i-1) + Prob(i) ;
  }
  arma::vec RandVec = Rcpp::runif(1,0,1) ;
  int out = 0 ;
  while ( CumProb(out) < RandVec(0) ) out++ ;
  return out;
  // This function is checked with "dmvnorm" in mvtnorm package on 2018/01/26
} // rdiscrete_fn(arma::vec Prob)
