/////////////////////////////////////////////////////////////////////
// Change log
// 
//  * Add functions in 2_Function_createModel_Run.R to check convergences.
// 
//  * Replace ".cube_UT_cholSigma" with ".stacked_UT_cholSigma" 
//    as the old version of RcppArmadillo in REHL5 does not support it.
//    However, cube types can be used for computaitons. 
//
//  * Prevent alpha = 0 
//   : change 2_DataParam.cpp / S6_pi
//
//  * Some errors during initialization (with balance edits)
//  * Add a small epsilon 1e-6 to readData function in 1_Function_readData.R 
//  * max( Edit_matrix2[,1:n_var]%*%t(Y_in_checked[i_sample,])-Edit_matrix2[,"CONSTANT"] ) > ( 0 + 1e-6 ) 
//
//  * Some errors during initialization (with balance edits)
//  * Increase the epsilon to 1e-3 to readData function in 1_Function_readData.R 
//  * max( Edit_matrix2[,1:n_var]%*%t(Y_in_checked[i_sample,])-Edit_matrix2[,"CONSTANT"] ) > ( 0 + 1e-3 ) 
//
//  * Back to ( 0 + 1e-6 ) in readData function in 1_Function_readData.R
//  * Change function CParam::S_Add_SyntY in 2_DataParam.cpp
//  *   -> a few z_i's (whose y_i's are close to zero) forms a mixture component with a large variance. 
//  *      Do not necessarily use z_i, so redraw k from Categorical(pi) for the (few) units 
//  
//  2019-11-07, 1.0.2
//  * Add model_obj$compute_pred_Y() and model_obj$pred_Y
//  
//  2019-11-08, 1.0.3
//  * arma::vec temp_prob(init_n_occ_comp) ; temp_prob.fill(1.0/init_n_occ_comp) ; // R, S, K should be greater than 10.
//  
//  2019-11-08, 1.1.0
//  * Consider variable bounds in imputation stage 
//  
//  2019-11-08, 1.3.1
//  * Data augmentation under the assumption that p_M > 0.5 
//    CParam::void S10_DA(CData &Data) ; 
// 
//  2020-07-01, 1.5.2
//  * Put limit of Y_imp 
/////////////////////////////////////////////////////////////////////

#include "1_Main.h"

///////////////////////
RCPP_MODULE(IO_module){
  
  using namespace R ;
  using namespace Rcpp ;
  
  class_<CMain>( "modelobject" )
    
    .constructor< arma::vec, arma::vec >()     
    
    .property("Y_mat", &CMain::GetY_mat, &CMain::SetY_mat, "Y")
    .property("X_mat", &CMain::GetX_mat, &CMain::SetX_mat, "X")
    .property(".Y_NA_mat", &CMain::GetY_NA_mat, &CMain::SetY_NA_mat, "Y_NA")
    .property(".X_NA_mat", &CMain::GetX_NA_mat, &CMain::SetX_NA_mat, "X_NA")
    .property(".D_l_vec", &CMain::GetD_l_vec, &CMain::SetD_l_vec, ".D_l_vec")
    .property("trt_Ind", &CMain::Gettrt_Ind, &CMain::Settrt_Ind, "trt_Ind")
    .property("bound_L", &CMain::Getbound_L, &CMain::Setbound_L, "bound_L")
    .property("bound_U", &CMain::Getbound_U, &CMain::Setbound_U, "bound_U")

    .property("msg_level", &CMain::Getmsg_level, &CMain::Setmsg_level, "0: errors; 1: error and warnings; 2: errors, warnings and info")
    .property(".where_we_are", &CMain::Getwhere_we_are, &CMain::Setwhere_we_are, "where_we_are")

    .method(".Initialization", &CMain::Initialization, "Initialization")
    .method("Iterate", &CMain::Iterate, "Run one iteration of MCMC algorithm")
    .method("Run", &CMain::Run, "Run multiple iterations of MCMC algorithm")

    .method("compute_pred_Y", &CMain::compute_pred_Y, "Run multiple iterations of MCMC algorithm")
    .property("pred_Y", &CMain::Getpred_Y)

    .property("delta", &CMain::Getdelta, &CMain::Setdelta, "delta")
		.property("p_resp", &CMain::Getp_resp, &CMain::Setp_resp, "p_resp")

    // To check the code
    .property("r_i_vec", &CMain::Getr_i_vec, &CMain::Setr_i_vec, "r_i_vec")
    .property("s_i_vec", &CMain::Gets_i_vec, &CMain::Sets_i_vec, "s_i_vec")
    .property("k_i_vec", &CMain::Getk_i_vec, &CMain::Setk_i_vec, "k_i_vec")
    .property("psi_cube", &CMain::Getpsi_cube, &CMain::Setpsi_cube, "psi_cube")
    .property("Beta_cube", &CMain::GetBeta_cube, &CMain::SetBeta_cube, "Beta_cube")

    .property("UT_Sigma_cube", &CMain::GetUT_Sigma_cube, "UT_Sigma_cube")
    .property("log_prob", &CMain::Getlog_prob, "log_prob")

    .property("n_sample", &CMain::Getn_sample, "n_sample")

    .property(".test_Y_std_synt", &CMain::Gettest_Y_std_synt, &CMain::Settest_Y_std_synt, "test_Y_std_synt")

    // To check Hang Kim's function
    // .method(".test_log_dMVN_fn", &CMain::test_log_dMVN_fn, "test_log_dMVN_fn")
    // .method(".test_log_dMVN_UT_chol_fn", &CMain::test_log_dMVN_UT_chol_fn, "test_log_dMVN_UT_chol_fn")
    // .method(".test_rMVN_fn", &CMain::test_rMVN_fn, "test_rMVN_fn")
    // .method(".test_rMVN_UT_chol_fn", &CMain::test_rMVN_UT_chol_fn, "test_rMVN_UT_chol_fn")
    // .method(".test_rIW_fn", &CMain::test_rIW_fn, "test_rIW_fn")
    // .method(".test_rdiscrete_fn", &CMain::test_rdiscrete_fn, "test_rdiscrete_fn")
    
    ; // Do not delete ;
  
}       

///////////////////////
CMain::CMain(arma::vec max_R_S_K_, arma::vec prior_vec_) {
  Data.max_R_S_K = max_R_S_K_ ;
  Data.a_R = prior_vec_(0) ;
  Data.b_R = prior_vec_(1) ; Data.a_S = prior_vec_(2) ; Data.b_S = prior_vec_(3) ;
  Data.a_K = prior_vec_(4) ; Data.b_K = prior_vec_(5) ; Data.psi_0 = prior_vec_(6) ; Data.b_theta = prior_vec_(7) ;
  Data.a_tau = prior_vec_(8) ; Data.b_tau = prior_vec_(9) ; Data. b_delta = prior_vec_(10) ;
} // CMain::CMain

CMain::~CMain(){
} //Destructor

void CMain::Initialization() {
  IterCount = 0 ;
  Data.n_sample = Param.Y_mat_imp.n_rows ; Data.p_y = Param.Y_mat_imp.n_cols ; Data.p_x = Param.X_mat_imp.n_cols ;
  Data.Initialization() ;
	// std::cout << "Finish Data.Initialization" << std::endl ;
  Param.Initialization(Data) ;
	// std::cout << "Finish Param.Initialization" << std::endl ;
}

void CMain::Iterate(){
  IterCount++; // std::cout << "IterCount" << std::endl ;
  Param.Iterate(IterCount, Data) ;
}

void CMain::Run(int n_iter_){
  for (int i_iter=0; i_iter<n_iter_; i_iter++) {
    IterCount++;
    Param.Iterate(IterCount, Data) ;
  }
}

void CMain::compute_pred_Y(){
  Param.compute_pred_Y(Data) ;
}

arma::mat CMain::Getpred_Y() { return Param.pred_Y ; }

arma::mat CMain::GetY_mat() {
  arma::mat Y_mat_ = Param.Y_mat_imp.rows(0,Data.n_sample-1) ;
  return Y_mat_ ;
}
void CMain::SetY_mat(arma::mat Y_mat_) { Param.Y_mat_imp = Y_mat_ ; }

arma::mat CMain::GetX_mat() {
  arma::mat X_mat_ = Param.X_mat_imp.rows(0,Data.n_sample-1) ;
  return X_mat_ ;
}
void CMain::SetX_mat(arma::mat X_mat_) { Param.X_mat_imp = X_mat_ ; }

arma::mat CMain::GetY_NA_mat() { return Data.Y_NA_mat ; }
void CMain::SetY_NA_mat(arma::mat Y_NA_mat_) { Data.Y_NA_mat = Y_NA_mat_ ; }

arma::mat CMain::GetX_NA_mat() { return Data.X_NA_mat ; }
void CMain::SetX_NA_mat(arma::mat X_NA_mat_) { Data.X_NA_mat = X_NA_mat_ ; }

arma::vec CMain::GetD_l_vec() { return Data.D_l_vec ; }
void CMain::SetD_l_vec(arma::vec D_l_vec_) { Data.D_l_vec = D_l_vec_ ; }

arma::vec CMain::Gettrt_Ind() { return Data.trt_Ind ; }
void CMain::Settrt_Ind(arma::vec trt_Ind_) { Data.trt_Ind = trt_Ind_ ; }

arma::vec CMain::Getbound_L() { return Data.bound_L ; }
void CMain::Setbound_L(arma::vec bound_L_) { Data.bound_L = bound_L_ ; }
arma::vec CMain::Getbound_U() { return Data.bound_U ; }
void CMain::Setbound_U(arma::vec bound_U_) { Data.bound_U = bound_U_ ; }

arma::vec CMain::Getdelta() { return Param.delta_vec ; }
void CMain::Setdelta(arma::vec delta_vec_) { Param.delta_vec = delta_vec_ ; }

int CMain::Getp_resp() { return Data.p_resp ; }
void CMain::Setp_resp(int p_resp_) { Data.p_resp = p_resp_ ; }

int CMain::Getmsg_level() { return Data.msg_level ; }
void CMain::Setmsg_level(int msg_level_) { Data.msg_level = msg_level_ ; }

std::string CMain::Getwhere_we_are() { return Param.where_we_are ; }
void CMain::Setwhere_we_are(std::string where_we_are_) { Param.where_we_are = where_we_are_ ; }

///////////////////  To check the code  //////////////////////////////

arma::cube CMain::GetBeta_cube() { return Param.Beta_cube ; }
void CMain::SetBeta_cube(arma::cube Beta_cube_) { Param.Beta_cube = Beta_cube_ ; }
arma::vec CMain::Getr_i_vec() {
  arma::mat r_i_vec_ = Param.r_i_vec.rows(0,Data.n_sample-1) ;
  return r_i_vec_ ;
}
void CMain::Setr_i_vec(arma::vec r_i_vec_) { Param.r_i_vec = r_i_vec_ ; }
arma::vec CMain::Gets_i_vec() {
  arma::mat s_i_vec_ = Param.s_i_vec.rows(0,Data.n_sample-1) ;
  return s_i_vec_ ;
}
void CMain::Sets_i_vec(arma::vec s_i_vec_) { Param.s_i_vec = s_i_vec_ ; }
arma::vec CMain::Getk_i_vec() {
  arma::mat k_i_vec_ = Param.k_i_vec.rows(0,Data.n_sample-1) ;
  return k_i_vec_ ;
}
void CMain::Setk_i_vec(arma::vec k_i_vec_) { Param.k_i_vec = k_i_vec_ ; }
arma::cube CMain::Getpsi_cube() { return Param.psi_cube ; }
void CMain::Setpsi_cube(arma::cube psi_cube_) { Param.psi_cube = psi_cube_ ; }
arma::mat CMain::Gettest_Y_std_synt() { return Param.test_Y_std_synt ; }
void CMain::Settest_Y_std_synt(arma::mat test_Y_std_synt_) { Param.test_Y_std_synt = test_Y_std_synt_ ; }

arma::cube CMain::GetUT_Sigma_cube() { return Param.UT_Sigma_cube ; }
double CMain::Getlog_prob() { return Param.log_prob ; }

int CMain::Getn_sample() { return Data.n_sample ; }


///////////////////  To check Hang Kim's function //////////////////////////////

// double CMain::test_log_dMVN_fn(arma::vec x, arma::vec mu, arma::mat sigma_mat){
//   return(Param.log_dMVN_fn(x, mu, sigma_mat)) ;
// } // This function is checked with "dmvnorm" in mvtnorm package on 2018/01/26
// double CMain::test_log_dMVN_UT_chol_fn(arma::vec x, arma::vec mu, arma::mat UT_chol){
//   return( Param.log_dMVN_UT_chol_fn(x, mu, UT_chol) ) ;
// } // This function is checked with "dmvnorm" in mvtnorm package on 2018/01/26
//
// arma::vec CMain::test_rMVN_fn(arma::vec mu, arma::mat sigma_mat){
//   return( Param.rMVN_fn(mu, sigma_mat) ) ;
// } // This function is checked on 2018/01/27
// arma::vec CMain::test_rMVN_UT_chol_fn(arma::vec mu, arma::mat UT_chol){
//   return( Param.rMVN_UT_chol_fn(mu, UT_chol) ) ;
// } // This function is checked on 2018/01/27
//
// arma::mat CMain::test_rIW_fn(int nu_, arma::mat Phi_){
//   return( Param.rIW_fn( nu_, Phi_ ) ) ;
// } // This function is checked on 2018/01/27
//
// int CMain::test_rdiscrete_fn(arma::vec Prob){
//   return( Param.rdiscrete_fn(Prob) );
// } // This function is checked on 2018/01/26
