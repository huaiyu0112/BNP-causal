readData <- function( Response_var, trt_indicator, Cont_pred, Categ_pred, bound_L=NULL, bound_U=NULL, RandomSeed=99 ){
  
	set.seed(RandomSeed)
	
  if (is.null(Response_var)) stop("Response_var is NULL") 
  if (is.null(trt_indicator)) stop("trt_indicator is NULL") 
	if (is.null(Cont_pred)) stop("Cont_pred is NULL") 
  if (is.null(Categ_pred)) stop("Categ_pred is NULL") 
  
	if ( is.null( dim(Response_var)[[2]]) ){ 
		p_resp = 1 
		n_row_resp = length(Response_var)
	} else {
		p_resp = dim(Response_var)[[2]]
		n_row_resp = dim(Response_var)[[1]]
	}
		
  if ( is.null(dim(Cont_pred)[[2]]) ){
    if (n_row_resp != length(Cont_pred)) stop("length(Response_var) != length(Cont_pred)")
  } else {
    if (n_row_resp != dim(Cont_pred)[[1]]) stop("length(Response_var) != dim(Cont_pred)[[1]]")
  }
  if (is.null(dim(Categ_pred))){
    stop("The package is designed for data with more than one categorical predictor.")
  } else {
    if (n_row_resp != dim(Categ_pred)[[1]]) stop("length(Response_var) != dim(Categ_pred)[[1]]")
  }
  	
  trt_Ind = trt_indicator
  Y_input = cbind(Response_var,Cont_pred)
  X_input = Categ_pred
  
  NA_Y_mat = is.na( Y_input )
	NA_X_mat = is.na( X_input )
	
	if ( is.null(bound_L) ){
	  bound_L = rep(-Inf, dim(Y_input)[[2]])
		for (j in 1:dim(Y_input)[[2]]){
			bound_L[j] = min(Y_input[,j],na.rm=TRUE)
		}
	} else {
	  if (length(bound_L)!=dim(Y_input)[[2]]){
	    stop("length(bound_L)!=dim(cbind(Response_var,Cont_pred))[[2]]")
	  }
	} #
	if ( is.null(bound_U) ){
	  bound_U = rep(Inf, dim(Y_input)[[2]])
		for (j in 1:dim(Y_input)[[2]]){
			bound_U[j] = max(Y_input[,j],na.rm=TRUE)
		}
	} else {
	  if (length(bound_U)!=dim(Y_input)[[2]]){
	    stop("length(bound_U)!=dim(cbind(Response_var,Cont_pred))[[2]]")
	  }
	} #
	
	for (i_sample in 1:dim(Y_input)[[1]]){
	  y_vec = Y_input[i_sample,] ; y_na_vec = NA_Y_mat[i_sample,] ; SEQ = which(y_na_vec==0)
	  check = (y_vec[SEQ]>=bound_L[SEQ]) * (y_vec[SEQ]<=bound_U[SEQ])
	  if ( sum(check) < length(SEQ) ){
	    stop(paste0("Some observed values in cbind(Response_var,Cont_pred)[",i_sample,",] are outside of the bound [L,U]"))
	  } #
	} #
	
	n_sample = dim(Y_input)[[1]] ; p_Y = dim(Y_input)[[2]]
	Y_mat_std = array(0,c(n_sample,p_Y))
	mean_Y_input = sd_Y_input = rep(0,p_Y)
	bound_L_std = bound_U_std = rep(0,p_Y) 
	for (l in 1:p_Y){
		mean_Y_input[l] = mean(Y_input[,l], na.rm=TRUE)
		sd_Y_input[l] = sd(Y_input[,l], na.rm=TRUE)
		Y_mat_std[,l] = ( Y_input[,l] - mean_Y_input[l] ) / sd_Y_input[l]
		bound_L_std[l] = ( bound_L[l] -  mean_Y_input[l] ) / sd_Y_input[l]
		bound_U_std[l] = ( bound_U[l] -  mean_Y_input[l] ) / sd_Y_input[l]
	}
	
	p_X = dim(X_input)[[2]] ; D_l_vec = rep(0,p_X)
	X_mat_std = array(0,c(n_sample,p_X))
	for (l in 1:p_X){
		unique_l = sort(unique(X_input[,l]))		
		D_l_vec[l] = length(unique_l)
		for (i in 1:n_sample){
			if (is.na(X_input[i,l])){ 
				X_mat_std[i,l] = X_input[i,l]
			} else {
				X_mat_std[i,l] = which( X_input[i,l] == unique_l ) - 1
			}
		}		
	} # for (l)
	
	# Y_mat_std : standardized, X_mat_std : 0 ~ (D_l_vec(l)-1)
	
	HCMMcausal_input = list(n_sample=n_sample, p_Y=p_Y, Y_mat_std=Y_mat_std, mean_Y_input=mean_Y_input, sd_Y_input=sd_Y_input, NA_Y_mat = NA_Y_mat, p_X=p_X, D_l_vec=D_l_vec, X_mat_std=X_mat_std, NA_X_mat = NA_X_mat, trt_Ind=trt_Ind, bound_L_std=bound_L_std, bound_U_std=bound_U_std, p_resp=p_resp)
	
	class(HCMMcausal_input) <- "HCMMcausal.data"
	return(HCMMcausal_input)	
	
} # readData <- function
