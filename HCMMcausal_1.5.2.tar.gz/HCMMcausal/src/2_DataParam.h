#if !defined(_Param_H)
#define _Param_H

#include <RcppArmadillo.h>
#include <sstream>      // For convert int to string

class CData {

  public:
  CData() ; ~CData() ; // constructor, destructor
  
  void Initialization() ; 
  
  int p_y, p_x, p_x_star, nu_sigma, nu_phi, n_sample, msg_level, R, S, K, p_resp ;
  double a_R, b_R, a_S, b_S, a_K, b_K, psi_0, b_theta, a_tau, b_tau, b_delta ;
  arma::vec D_l_vec, max_R_S_K, trt_Ind, bound_L, bound_U ;
  arma::mat Y_NA_mat, X_NA_mat, Phi_0_mat ;
	arma::cube A_ij_cube ; 
  
};

class CParam {

  public:
	CParam() ; ~CParam(); // constructor, destructor
	
	void Initialization(CData &Data) ;
  void Iterate(int Iter, CData &Data) ;

  std::string where_we_are ;
	int p_resp ; 
	double log_prob ;
	arma::vec delta_vec ;
  arma::mat Y_mat_imp, X_mat_imp ;
	
  // To disply in R, moved from private:
  arma::vec r_i_vec, s_i_vec, k_i_vec ;
  arma::mat test_Y_std_synt, pred_Y ;
  arma::cube Beta_cube, psi_cube, UT_Sigma_cube ;
  void compute_pred_Y(CData &Data) ;

  private:
  CData Data ;

  arma::vec cube_to_vec_fn(arma::cube input_cube, int first_row, int last_row, int first_col, int last_col, int first_slice, int last_slice ) ;
  arma::vec x_to_x_star_fn(arma::vec x_vec, CData &Data) ;

  double log_dMVN_UT_chol_fn(arma::vec x, arma::vec mu, arma::mat UT_chol) ;
  arma::vec rMVN_UT_chol_fn(arma::vec mu, arma::mat UT_chol) ;
  arma::vec rDirichlet_fn( arma::vec alpha_vec ) ;
  arma::mat rWishart_UT_chol_fn( int nu, arma::mat UT_chol ) ;
  arma::mat rIW_UT_chol_fn( int nu, arma::mat UT_chol ) ;
  int rdiscrete_fn(arma::vec Prob) ;

  void S1_Beta_cube(CData &Data) ;
  void S2_Sigma_cube(CData &Data) ;
  void S3_theta_mat(CData &Data) ;
  void S4_Phi_mat(CData &Data) ;
  void S5_psi_cube(CData &Data) ;
  void S6a_log_pi_vec(CData &Data) ;
  void S6b_alpha_K(CData &Data) ;
  void S6c_k_i_vec(CData &Data) ;
  void S7a_log_eta_mat(CData &Data) ;
  void S7b_alpha_R(CData &Data) ;
  void S7c_r_i_vec(CData &Data) ;
  void S8a_log_lambda_mat(CData &Data) ;
  void S8b_alpha_S(CData &Data) ;
  void S8c_s_i_vec(CData &Data) ;
  void S9_tau_inv_diag_vec(CData &Data) ;

  // void S10_DA(CData &Data) ;

  void S_impute_X_mat(CData &Data) ;
  void S_impute_Y_mat(CData &Data) ;
  void S_update_delta(CData &Data) ;
  void S_upated_log_prob(CData &Data) ;

  // void S_add_test_Y_std_synt(CData &Data) ;

  double alpha_R, alpha_S, alpha_K ;
  arma::vec tau_inv_diag_vec, n_r_vec, n_s_vec, n_k_vec ;
  arma::mat theta_mat, Phi_mat, log_eta_mat, log_lambda_mat, log_pi_vec, n_k_r_mat, n_k_s_mat ;

};


#endif
