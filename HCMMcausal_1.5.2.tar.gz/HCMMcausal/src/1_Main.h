#if !defined(_Main_H)
#define _Main_H

#include <RcppArmadillo.h>
#include "2_DataParam.h"

class CMain {
	
 public:
   
  CMain(arma::vec, arma::vec) ;
	~CMain() ; //destructor
	void Initialization() ;

  arma::mat GetY_mat() ;   void SetY_mat(arma::mat) ;
	arma::mat GetX_mat() ;   void SetX_mat(arma::mat) ;
	arma::mat GetY_NA_mat() ;   void SetY_NA_mat(arma::mat) ;
	arma::mat GetX_NA_mat() ;   void SetX_NA_mat(arma::mat) ;
	arma::vec GetD_l_vec() ;   void SetD_l_vec(arma::vec) ;
	arma::vec Gettrt_Ind() ;   void Settrt_Ind(arma::vec) ;
	arma::vec Getbound_L() ;   void Setbound_L(arma::vec) ;
	arma::vec Getbound_U() ;   void Setbound_U(arma::vec) ;
	int Getp_resp() ;  void Setp_resp(int) ;

	arma::vec Getdelta() ;   void Setdelta(arma::vec) ;
  int Getmsg_level() ;  void Setmsg_level(int) ;
  std::string Getwhere_we_are() ; void Setwhere_we_are(std::string) ;

  void Iterate() ; void Run(int n_iter_) ;

  void compute_pred_Y() ;
  arma::mat Getpred_Y() ;

  // To check the code

  arma::cube GetBeta_cube() ; void SetBeta_cube(arma::cube) ;
  arma::vec Getr_i_vec() ; void Setr_i_vec(arma::vec) ;
  arma::vec Gets_i_vec() ; void Sets_i_vec(arma::vec) ;
  arma::vec Getk_i_vec() ; void Setk_i_vec(arma::vec) ;
  arma::cube Getpsi_cube() ; void Setpsi_cube(arma::cube) ;

  arma::cube GetUT_Sigma_cube() ;
  double Getlog_prob() ;

  arma::mat Gettest_Y_std_synt() ; void Settest_Y_std_synt(arma::mat) ;

  int Getn_sample() ;

 private:

   CData Data ; CParam Param ;

   int IterCount ;
   arma::vec RandVec ;

};

#endif  //_CMain_H

